Установите flask: sudo pip2.7 install flask
Чтобы запустить сервер выполните команду `python2.7 demo.py` и перейдите на http://localhost:81/sentiment-demo
